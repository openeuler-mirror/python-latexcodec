.. automodule:: latexcodec.lexer
