.. automodule:: latexcodec.codec
