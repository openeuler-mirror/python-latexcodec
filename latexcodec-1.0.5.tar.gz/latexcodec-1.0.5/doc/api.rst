API
~~~

.. toctree::
    :maxdepth: 2

    api/codec
    api/lexer
