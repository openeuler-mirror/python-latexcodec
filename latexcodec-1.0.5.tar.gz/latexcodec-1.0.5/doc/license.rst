License
=======

.. include:: ../LICENSE.rst

.. rubric:: Remark

Versions 0.1 and 0.2 of the latexcodec package were written by
Peter Tröger, and were released under the Academic Free License 3.0.
The current version of the latexcodec package shares no code with those
earlier versions.
