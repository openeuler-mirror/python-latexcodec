Welcome to latexcodec's documentation!
======================================

:Release: |release|
:Date:    |today|

Contents
--------

.. toctree::
   :maxdepth: 2

   quickstart
   api
   changes
   authors
   license

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

