latexcodec
==========

|travis| |coveralls|

A lexer and codec to work with LaTeX code in Python.

* Download: http://pypi.python.org/pypi/latexcodec/#downloads

* Documentation: http://latexcodec.readthedocs.org/

* Development: http://github.com/mcmtroffaes/latexcodec/

.. |travis| image:: https://travis-ci.org/mcmtroffaes/latexcodec.png?branch=develop
    :target: https://travis-ci.org/mcmtroffaes/latexcodec
    :alt: travis-ci

.. |coveralls| image:: https://coveralls.io/repos/mcmtroffaes/latexcodec/badge.png?branch=develop
    :target: https://coveralls.io/r/mcmtroffaes/latexcodec?branch=develop
    :alt: coveralls.io

