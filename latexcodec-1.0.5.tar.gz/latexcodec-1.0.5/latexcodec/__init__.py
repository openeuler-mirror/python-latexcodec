import latexcodec.codec
latexcodec.codec.register()
